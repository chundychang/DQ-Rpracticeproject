# Screen 459.3: A Different App Structure
# In the line below, import the shiny library so that it's available
# in both ui.R and server.R



# Screen 459.5: Data Introduction And Cleaning
# In the lines below, import the hospital_los.csv file and process it according
# to the screen instructions. Categorical variables should be converted into 
# factor
